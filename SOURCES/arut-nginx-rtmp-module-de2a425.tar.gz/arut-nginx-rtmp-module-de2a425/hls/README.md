HLS is now a part of rtmp module
